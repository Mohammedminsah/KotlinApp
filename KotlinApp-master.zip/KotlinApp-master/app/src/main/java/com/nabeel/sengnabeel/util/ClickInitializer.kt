package com.nabeel.sengnabeel.util

interface ClickInitializer{
    fun initialize(anyButtonId : Int)
}